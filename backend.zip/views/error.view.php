<section>
	<div class="d-flex justify-content-center m-height full-width align-items-center" style="align-items: center!important;justify-content: center!important;display: flex!important;">
		<div class="error-container text-center my-auto">
			<h1 class="error-number mb-2">404</h1>
			<h3 class="mb-4">Error</h3>
			<p class="mb-4">Connection failed please check your database settings</p>
			<a href="https://codecanyon.net/user/wicombit#contact" target="_blank"><button class="btn btn-outline-primary rounded">Contact Support</button></a>
		</div>
	</div>
</section>

</body>
</html>