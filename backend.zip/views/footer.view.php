<!--Jquery
<script type="text/javascript" src="../assets/js/jquery-3.2.1.min.js"></script>-->
<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../assets/js/popper.min.js"></script>

<script type="text/javascript" src="../assets/js/modernizr.custom.js"></script>

<script type="text/javascript" src="../assets/plugins/customScroll/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="../assets/plugins/sortable2/sortable.min.js"></script>
<script type="text/javascript" src="../assets/plugins/date-range/moment.min.js"></script>
<script type="text/javascript" src="../assets/plugins/date-range/daterangepicker.js"></script>
<script type="text/javascript" src="../assets/plugins/data-tables/datatables.min.js"></script>
<script type="text/javascript" src="../assets/plugins/editable/editable.js"></script>

<script src="../assets/js/main.js"></script>
<script src="../assets/js/lightbox.js"></script>
<script src="../assets/js/custom.js"></script>

<script src="../assets/js/chosen.jquery.js" type="text/javascript"></script>
<script src="../assets/js/ImageSelect.jquery.js" type="text/javascript"></script>
  <script type="text/javascript">
    $(".my-select").chosen({width:"100%"});
  </script>

</body>
</html>