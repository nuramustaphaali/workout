<?php

require '../admin/config.php';
require './app_functions.php';

$connect = connect();


?>